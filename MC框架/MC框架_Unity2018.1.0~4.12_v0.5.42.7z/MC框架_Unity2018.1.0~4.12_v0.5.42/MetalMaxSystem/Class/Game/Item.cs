﻿namespace MetalMaxSystem
{
    /// <summary>
    /// 道具(继承Unit并追加专用信息)
    /// </summary>
    public class Item : Unit 
    { 
        
    }
}
