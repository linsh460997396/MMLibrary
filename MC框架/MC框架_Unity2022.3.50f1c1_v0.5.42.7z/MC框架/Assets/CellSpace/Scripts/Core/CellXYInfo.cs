namespace CellSpace
{
    /// <summary>
    /// 存储XY坐标的结构体
    /// </summary>
    public struct CellXYInfo
    {
        public int x, y;
    }
}
