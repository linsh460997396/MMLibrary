namespace MetalMaxSystem
{
    //枚举是值类型

    /// <summary>
    /// 单位计数枚举
    /// </summary>
    public enum UnitCount
    {
        All,
        Alive,
        Dead
    }
}
