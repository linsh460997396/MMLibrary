﻿namespace MetalMaxSystem
{
    //枚举是值类型

    /// <summary>
    /// 指令目标枚举
    /// </summary>
    public enum OrderTarget
    {
        None,
        Point,
        Unit,
        Item
    }
}
